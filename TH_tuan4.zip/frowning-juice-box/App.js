import * as React from 'react';
import { Text, View, StyleSheet,TouchableOpacity,Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.container1}>
      <View style={styles.container12}>
        <View style={styles.container1_1}>
          <Image
          style={styles.img}
           source={require('./book.png')}
          />
          <Text style={{fontWeight:500,fontSize:12,paddingTop:10}}>Mã giảm giá đã lưu</Text>
        </View>
        <View style={styles.container1_2}>
          <Text style={{fontWeight:500, fontSize:12,paddingBottom:10}}>Nguyên hàm tích phân và ứng dụng</Text>
          <Text style={{fontWeight:500,fontSize:10, paddingBottom:10}}>Cung cấp bởi TikiTranding</Text>
          <Text style={{color:'red',fontWeight:500,paddingBottom:10}}>141.800đ</Text>
          <Text style={{color:'#808080',fontWeight:500,fontSize:10}}>141.800đ</Text>
          <View style={styles.container1_2_1}>
            <TouchableOpacity style={styles.bttru}>
              <Text style={{fontWeight:500}}>-</Text>
            </TouchableOpacity>
            <Text>1</Text>
            <TouchableOpacity
            style={styles.btcong}>
              <Text style={{fontWeight:500}}>+</Text>
            </TouchableOpacity>
            <Text style={{paddingLeft:50,color:'blue',fontWeight:500 }} >Mua sau</Text>
          </View>
          <Text style={{color:'blue',fontWeight:500, paddingTop:10}}>Xem tại đây</Text>
        </View>
        </View>
        <View style={styles.container1_3}>
          <View style={styles.container1_3_1}>
            <View style={styles.bt}>
              <View style={styles.btvang}></View>
              <Text style={{fontSize:17,fontWeight:500,padding:10}}>Mã giảm giá</Text>
            </View>
            <TouchableOpacity style={styles.btapdung}>
              <Text style={{fontWeight:500,fontSize:17,color:'#ffff'}}>Áp dụng</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={styles.container2}>
        <View style={styles.container2_1}>
          <Text style={{fontWeight:500, fontSize:11}}>Bạn có phiếu quà tặng Tiki/Got it/ Urbox?</Text>
          <Text style={{fontWeight:500, fontSize:10 ,color:'#134FEC', paddingLeft:15}}>Nhập tại đây?</Text>
        </View>
        <View style={styles.container2_2}>
          <Text style={{fontWeight:500,fontSize:18}}>Tạm tính:</Text>
          <Text style={{paddingLeft:150,fontWeight:500,color:'red',paddingTop:3}} >148.000đ</Text>
        </View>
      </View>
      <View style={styles.container3}>
        <View style={styles.container3_1}>
          <Text style={{fontWeight:500,color:'#808080',fontSize:18}}>Thành Tiền</Text>
          <Text style={{fontWeight:500, paddingLeft:155, paddingTop:5,color:'red'}}>148.000đ</Text>
        </View>
        <TouchableOpacity style={styles.btdathang}>
              <Text style={{fontSize:20,paddingTop:5,color:'#ffff'}}>Tiến hành đặt hàng</Text>
            </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'ffff',
    padding: 8,
  },
  
  img:{
   
    width:104,
    height:127
    },
  container1:{
    flex:1,
    flexDirection:'column',
    paddingTop:9
  },
  container12:{
    flexDirection:'row',
  },
  container1_1:{
    
    
  },
  container1_2:{
    
    
    padding:10,
  },
  container1_2_1:{
    flexDirection:'row',
    paddingTop:5
  },
  btcong:{
    border:'1px solid black',
    backgroundColor:'gray',
    textAlign:'center',
    width:20,
    marginLeft:10
  },
  bttru:{
    border:'1px solid black',
    backgroundColor:'gray',
    textAlign:'center',
    width:20,
    marginRight:10
  },
  container2:{
    backgroundColor:'#C4C4C4',
    flex:1,
  },
  container2_1:{
    
    flexDirection:'row',
    padding:15,
    marginBottom:20,
    backgroundColor:'#ffff',
    marginTop:20
  },
  container2_2:{
    backgroundColor:'#ffff',
    flexDirection:'row',
    padding:10
  },
  btapdung:{
     border:'1px solid black',
    backgroundColor:'#0A5EB7',
    width:100,
    height:50,
    textAlign:'center',
    paddingTop:12,
    marginLeft:20,
    marginTop:10
  },
  bt:{
    border:'1px solid black',
    width:200,
    height:50,
    marginTop:10,
    flexDirection:'row'
  },
  container1_3_1:{
    flexDirection:'row',
  },
  container3_1:{
    flexDirection:'row',
    marginTop:10
  },
  btdathang:{
    border:'1px solid black',
    textAlign:'center',
    height:40,
    marginTop:10,
    backgroundColor:'#E53935',
    borderRadius:5
  },
  btvang:{
    backgroundColor:'#F2DD1B',
    width:50,
    height:20,
    margin:10,
    marginTop:15
  }
  
  
});
